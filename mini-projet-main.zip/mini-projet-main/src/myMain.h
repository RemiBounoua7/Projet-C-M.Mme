#pragma once
int myMain(int curMap);